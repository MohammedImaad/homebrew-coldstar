- Prompted to retore files when replugging drive into USB
- UI flows like unessessary text prompting about 'unsafe or security risks'

TODO:

- RWAs, xStocks & Comodities options
- Docker for windows
- Security Autiting & Fixing
- Multichain                